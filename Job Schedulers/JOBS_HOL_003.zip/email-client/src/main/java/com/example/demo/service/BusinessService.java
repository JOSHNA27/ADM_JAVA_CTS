package com.example.demo.service;

import org.springframework.stereotype.Service;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;

/**
 * BusinessService
 */
@Service
public class BusinessService {

    private JavaMailSender mailSender;

    @Autowired
    public BusinessService(JavaMailSender mailSender) {
        this.mailSender = mailSender;
    }

    public void sendEmail() {
        String from = "tonystack422@gmail.com";
        String to = "dilsadmohammed4@gmail.com";
        SimpleMailMessage message = new SimpleMailMessage();
        message.setFrom(from);
        message.setTo(to);
        message.setSubject("This is a plain text");
        message.setText("Hello guys! This is a plain text");
        mailSender.send(message);

    }
}