package com.example.emailclient;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmailClientApplicationTests {

	@Test
	void contextLoads() {
	}

}
